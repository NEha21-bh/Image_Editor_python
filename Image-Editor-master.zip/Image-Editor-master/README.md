# Image-Editor
The “Image Editor” application allows users to edit any image using various tools.
It has features like crop, filter, rotate, B/W, border, sketch etc. 
It has an option for taking pictures through camera and editing them or even uploading a picture from system for editing. 
